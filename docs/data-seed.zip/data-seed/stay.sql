insert into MY_TABLE (id, first_name, last_name, birth)
values  (10001, 'Georgi', 'Facello', 'M'),
        (10002, 'Bezalel', 'Simmel', 'F'),
        (10003, 'Parto', 'Bamford', 'M'),
        (10004, 'Chirstian', 'Koblick', 'M'),
        (10005, 'Kyoichi', 'Maliniak', 'M'),
        (10006, 'Anneke', 'Preusig', 'F'),
        (10007, 'Tzvetan', 'Zielinski', 'F'),
        (10008, 'Saniya', 'Kalloufi', 'M'),
        (10009, 'Sumant', 'Peac', 'F'),
        (10010, 'Duangkaew', 'Piveteau', 'F');