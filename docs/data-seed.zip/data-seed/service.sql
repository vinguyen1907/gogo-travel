insert into public.service (id, name)
values  ('1', 'Hà Nội Luxury Hotel'),
        ('2', 'Ho Chi Minh Grand Hotel'),
        ('3', 'Da Nang Beach Resort'),
        ('4', 'Phu Quoc Island Resort'),
        ('5', 'Hoi An Ancient Hotel'),
        ('6', 'Hue Central Motel'),
        ('7', 'Can Tho Riverside Motel'),
        ('8', 'New York Central Park Hotel'),
        ('9', 'Paris Eiffel Hotel'),
        ('10', 'Dubai Infinity Resort');